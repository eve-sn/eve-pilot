"""
Smoke tests for the Finance module : dashboard, cash-flow plan, bank accounts.
"""

from datetime import date
from decimal import Decimal

from django.core import mail
from django.test import Client, TestCase, override_settings

from apps.finance.models import BankAccount, BudgetLine, CashflowEntry
from apps.projects.models import Donor, Project
from apps.references.models import BudgetCategory


class FinanceDashboardTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.donor = Donor.objects.create(name="Donor F", donor_type=Donor.DonorType.MULTILATERAL)
        cls.project = Project.objects.create(
            code="F-001",
            title="Projet finance",
            primary_donor=cls.donor,
            total_budget=Decimal("50000000.00"),
            currency="XOF",
            start_date=date(2026, 1, 1),
            end_date=date(2026, 12, 31),
            status=Project.Status.ACTIVE,
            sector="NUTRITION",
            operating_contribution_amount=Decimal("5000000.00"),
            operating_contribution_pct=Decimal("10.00"),
        )
        cls.category = BudgetCategory.objects.create(
            code="CHARGES_TEST", name="Charges test"
        )
        cls.budget_line = BudgetLine.objects.create(
            project=None,  # Budget General
            category=cls.category,
            code="TEST-PAYROLL",
            description="Charges personnel test",
            planned_amount=Decimal("3000000.00"),
            currency="XOF",
            fiscal_year=2026,
        )
        cls.bank = BankAccount.objects.create(
            name="Test Bank",
            bank_name="Test SA",
            opening_balance=Decimal("100000.00"),
            opening_date=date(2026, 1, 1),
        )

    def setUp(self):
        from apps.accounts.models import User
        self.client = Client()
        admin = User(
            username=f"admin_{id(self)}",
            email=f"admin_{id(self)}@test.local",
            first_name="T", last_name="Admin",
            is_superuser=True, is_active=True,
        )
        admin.set_password("x")
        admin.save()
        self.client.force_login(admin)

    def test_dashboard_returns_200(self):
        response = self.client.get("/finance/")
        self.assertEqual(response.status_code, 200)

    def test_dashboard_shows_portfolio_and_revenue(self):
        response = self.client.get("/finance/")
        content = response.content.decode("utf-8")
        self.assertIn("Portefeuille projets", content)
        self.assertIn("Recettes du Budget General", content)
        # Operating contribution from cls.project should be summed.
        self.assertIn("5000000", content.replace(" ", ""))

    def test_dashboard_shows_bank_section(self):
        response = self.client.get("/finance/")
        content = response.content.decode("utf-8")
        self.assertIn("Comptes bancaires EVE", content)
        self.assertIn("Test Bank", content)

    def test_dashboard_shows_operating_line_detail(self):
        response = self.client.get("/finance/")
        self.assertContains(response, "TEST-PAYROLL")


class CashflowDashboardTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.donor = Donor.objects.create(name="Donor C")
        cls.project = Project.objects.create(
            code="C-001",
            title="Cashflow project",
            primary_donor=cls.donor,
            start_date=date(2026, 1, 1),
            end_date=date(2026, 12, 31),
            status=Project.Status.ACTIVE,
        )
        cls.category = BudgetCategory.objects.create(code="CFLOW_TEST", name="Test")
        # Two months of receipts and one month of spend.
        CashflowEntry.objects.create(
            period_year=2026, period_month=1, label="Test receipt",
            direction=CashflowEntry.Direction.INCOMING,
            project=cls.project, planned_amount=Decimal("10000000.00"),
        )
        CashflowEntry.objects.create(
            period_year=2026, period_month=2, label="Test receipt",
            direction=CashflowEntry.Direction.INCOMING,
            project=cls.project, planned_amount=Decimal("5000000.00"),
        )
        CashflowEntry.objects.create(
            period_year=2026, period_month=1, label="Test spend",
            direction=CashflowEntry.Direction.OUTGOING,
            category=cls.category, planned_amount=Decimal("3000000.00"),
        )

    def setUp(self):
        from apps.accounts.models import User
        self.client = Client()
        admin = User(
            username=f"admin_{id(self)}",
            email=f"admin_{id(self)}@test.local",
            first_name="T", last_name="Admin",
            is_superuser=True, is_active=True,
        )
        admin.set_password("x")
        admin.save()
        self.client.force_login(admin)

    def test_cashflow_returns_200(self):
        response = self.client.get("/finance/tresorerie/")
        self.assertEqual(response.status_code, 200)

    def test_cashflow_shows_yearly_totals(self):
        response = self.client.get("/finance/tresorerie/")
        content = response.content.decode("utf-8")
        # Receipts: 10M + 5M = 15M; spend: 3M; net: 12M
        self.assertIn("15000000", content.replace(" ", ""))
        self.assertIn("3000000", content.replace(" ", ""))
        self.assertIn("12000000", content.replace(" ", ""))

    def test_cashflow_shows_section_headers(self):
        response = self.client.get("/finance/tresorerie/")
        self.assertContains(response, "Encaissements")
        self.assertContains(response, "Decaissements")
        self.assertContains(response, "Solde net mensuel")


class CashflowEntryConstraintTests(TestCase):
    def test_unique_per_period_label_direction(self):
        """The (year, month, label, direction) tuple is unique."""
        CashflowEntry.objects.create(
            period_year=2026, period_month=3, label="Same",
            direction=CashflowEntry.Direction.INCOMING,
            planned_amount=Decimal("1000.00"),
        )
        from django.db import IntegrityError, transaction
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                CashflowEntry.objects.create(
                    period_year=2026, period_month=3, label="Same",
                    direction=CashflowEntry.Direction.INCOMING,
                    planned_amount=Decimal("2000.00"),
                )


class BudgetLineNullableProjectTests(TestCase):
    def test_budget_line_can_have_no_project(self):
        cat = BudgetCategory.objects.create(code="X", name="X")
        line = BudgetLine.objects.create(
            project=None,
            category=cat,
            code="BG-LINE",
            description="Budget General line",
            planned_amount=Decimal("1.00"),
            fiscal_year=2026,
        )
        self.assertIsNone(line.project)


class CashRegisterValidationTests(TestCase):
    """Plafonds caisse : 40 000 par operation, 200 000 par semaine ISO."""

    @classmethod
    def setUpTestData(cls):
        from apps.finance.models import CashRegister

        cls.register = CashRegister.objects.create(name="Caisse test")

    def _make_movement(self, debit, day):
        from apps.finance.models import CashMovement
        from datetime import date

        return CashMovement(
            register=self.register,
            date_operation=date(2026, 5, day),
            label="Test op",
            debit=Decimal(str(debit)),
            credit=Decimal("0"),
        )

    def test_unit_cap_rejects_more_than_40000(self):
        from django.core.exceptions import ValidationError

        with self.assertRaises(ValidationError):
            self._make_movement(45000, 5).save()

    def test_unit_cap_accepts_exactly_40000(self):
        movement = self._make_movement(40000, 5)
        movement.save()
        self.assertIsNotNone(movement.pk)

    def test_weekly_cap_rejects_cumulative_over_200000(self):
        from django.core.exceptions import ValidationError

        # All five days are within the same ISO week (W19 of 2026 :
        # Monday 4 May -> Sunday 10 May).
        self._make_movement(40000, 4).save()
        self._make_movement(40000, 5).save()
        self._make_movement(40000, 6).save()
        self._make_movement(40000, 7).save()
        self._make_movement(40000, 8).save()  # cumul = 200 000 pile, OK
        with self.assertRaises(ValidationError):
            # operation suivante 1 FCFA -> cumul 200 001 -> rejet
            self._make_movement(1, 9).save()

    def test_weekly_cap_resets_across_iso_weeks(self):
        # 5 mai (W19) cumul 40k, puis 12 mai (W20) doit recommencer a 0
        self._make_movement(40000, 5).save()
        self._make_movement(40000, 12).save()  # autre semaine ISO -> OK


class FinancialStatementsTests(TestCase):
    """Compte de resultat + bilan : routes 200 et coherence comptable."""

    @classmethod
    def setUpTestData(cls):
        from datetime import date
        from apps.finance.models import (
            BankAccount, ChartOfAccount, JournalEntry, JournalLine,
        )

        bank = BankAccount.objects.create(name="Banque stmt test", bank_name="X")
        cls.treasury = ChartOfAccount.objects.create(
            code="5211.STMT", name="Tresorerie test", class_number=5,
            linked_bank_account=bank,
        )
        cls.charge = ChartOfAccount.objects.create(
            code="66.STMT", name="Charges personnel test (SYCEBNL classe 66)", class_number=6,
        )
        cls.produit = ChartOfAccount.objects.create(
            code="75.STMT", name="Subventions test", class_number=7,
        )
        # Ecriture 1 : charge 200 000 (debit charge / credit tresorerie)
        e1 = JournalEntry.objects.create(entry_date=date(2026, 1, 10), label="Charge test")
        JournalLine.objects.create(entry=e1, account=cls.charge, debit=Decimal("200000"), credit=Decimal("0"))
        JournalLine.objects.create(entry=e1, account=cls.treasury, debit=Decimal("0"), credit=Decimal("200000"))
        # Ecriture 2 : produit 500 000 (debit tresorerie / credit produit)
        e2 = JournalEntry.objects.create(entry_date=date(2026, 1, 11), label="Produit test")
        JournalLine.objects.create(entry=e2, account=cls.treasury, debit=Decimal("500000"), credit=Decimal("0"))
        JournalLine.objects.create(entry=e2, account=cls.produit, debit=Decimal("0"), credit=Decimal("500000"))

    def setUp(self):
        from apps.accounts.models import User
        self.client = Client()
        admin = User(
            username=f"admin_{id(self)}",
            email=f"admin_{id(self)}@test.local",
            first_name="T", last_name="Admin",
            is_superuser=True, is_active=True,
        )
        admin.set_password("x")
        admin.save()
        self.client.force_login(admin)

    def test_income_statement_returns_200_and_computes_result(self):
        response = self.client.get("/finance/compte-resultat/")
        self.assertEqual(response.status_code, 200)
        # produits 500 000 - charges 200 000 = resultat 300 000 (excedent)
        content = response.content.decode("utf-8")
        self.assertIn("300000", content.replace(" ", ""))
        self.assertIn("Excedent", content)

    def test_balance_sheet_returns_200_and_is_balanced(self):
        response = self.client.get("/finance/bilan/")
        self.assertEqual(response.status_code, 200)
        # tresorerie nette = -200000 + 500000 = +300000 -> actif
        # resultat +300000 -> passif. Bilan equilibre.
        self.assertContains(response, "OK")

    def test_balance_sheet_balances_actif_equals_passif(self):
        response = self.client.get("/finance/bilan/")
        self.assertTrue(response.context["is_balanced"])
        # Nouveau modele SYCEBNL : on compare total_actif (BZ) vs total_passif (DZ).
        self.assertEqual(
            response.context["total_actif"],
            response.context["total_passif"],
        )


class ChartOfAccountsViewTests(TestCase):
    """Smoke test plan comptable SYCEBNL : route 200 + comptes de liaison rendus."""

    @classmethod
    def setUpTestData(cls):
        from apps.finance.models import ChartOfAccount

        cls.parent = ChartOfAccount.objects.create(
            code="181",
            name="Comptes de liaison projets EVE",
            class_number=1,
        )
        cls.liaison = ChartOfAccount.objects.create(
            code="181.10",
            name="Liaison Test Project",
            class_number=1,
            parent=cls.parent,
            is_liaison=True,
        )
        cls.account_bank = ChartOfAccount.objects.create(
            code="512.10",
            name="Banque test",
            class_number=5,
        )

    def setUp(self):
        from apps.accounts.models import User
        self.client = Client()
        admin = User(
            username=f"admin_{id(self)}",
            email=f"admin_{id(self)}@test.local",
            first_name="T", last_name="Admin",
            is_superuser=True, is_active=True,
        )
        admin.set_password("x")
        admin.save()
        self.client.force_login(admin)

    def test_chart_of_accounts_returns_200(self):
        response = self.client.get("/finance/plan-comptable/")
        self.assertEqual(response.status_code, 200)

    def test_chart_of_accounts_lists_liaison_account(self):
        response = self.client.get("/finance/plan-comptable/")
        self.assertContains(response, "181.10")
        self.assertContains(response, "Liaison Test Project")
        self.assertContains(response, "LIAISON")


class JournalPostingTests(TestCase):
    """Auto-generation des ecritures en partie double depuis BankMovement."""

    @classmethod
    def setUpTestData(cls):
        from datetime import date
        from apps.finance.models import BankAccount, ChartOfAccount

        cls.bank = BankAccount.objects.create(name="Banque test posting", bank_name="X")
        # Compte de tresorerie 512.x lie au compte bancaire
        cls.treasury = ChartOfAccount.objects.create(
            code="5211.99", name="Banque test - tresorerie", class_number=5,
            linked_bank_account=cls.bank,
        )
        # Compte de charge contrepartie (SYCEBNL classe 66 = charges de personnel)
        cls.charge = ChartOfAccount.objects.create(
            code="66.99", name="Charges de personnel test", class_number=6,
        )
        # Compte de produit contrepartie
        cls.produit = ChartOfAccount.objects.create(
            code="75.99", name="Subventions test", class_number=7,
        )

    def test_no_entry_without_contra_account(self):
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 1),
            reference="NOCONTRA", label="Sans imputation",
            debit=Decimal("50000"), credit=Decimal("0"),
        )
        self.assertFalse(JournalEntry.objects.filter(source_bank_movement=m).exists())

    def test_debit_movement_posts_debit_contra_credit_treasury(self):
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 2),
            reference="PAY-1", label="Paiement salaire",
            debit=Decimal("120000"), credit=Decimal("0"),
            contra_account=self.charge,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertTrue(entry.is_balanced)
        self.assertEqual(entry.total_debit, Decimal("120000"))
        charge_line = entry.lines.get(account=self.charge)
        treasury_line = entry.lines.get(account=self.treasury)
        self.assertEqual(charge_line.debit, Decimal("120000"))
        self.assertEqual(treasury_line.credit, Decimal("120000"))

    def test_credit_movement_posts_debit_treasury_credit_contra(self):
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 3),
            reference="SUBV-1", label="Subvention recue",
            debit=Decimal("0"), credit=Decimal("900000"),
            contra_account=self.produit,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertTrue(entry.is_balanced)
        treasury_line = entry.lines.get(account=self.treasury)
        produit_line = entry.lines.get(account=self.produit)
        self.assertEqual(treasury_line.debit, Decimal("900000"))
        self.assertEqual(produit_line.credit, Decimal("900000"))

    def test_changing_contra_account_regenerates_entry(self):
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 4),
            reference="REGEN-1", label="Mouvement a re-imputer",
            debit=Decimal("30000"), credit=Decimal("0"),
            contra_account=self.charge,
        )
        first = JournalEntry.objects.get(source_bank_movement=m)
        self.assertEqual(first.lines.get(account=self.charge).debit, Decimal("30000"))
        # Re-imputation
        m.contra_account = self.produit
        m.save()
        m.refresh_from_db()
        entry = JournalEntry.objects.get(source_bank_movement=m)
        # L'ancienne ligne sur self.charge a disparu, remplacee par self.produit
        self.assertFalse(entry.lines.filter(account=self.charge).exists())
        self.assertTrue(entry.lines.filter(account=self.produit).exists())
        self.assertTrue(entry.is_balanced)


class SycebnlProjectFundingTests(TestCase):
    """Mecanique SYCEBNL projets de developpement (App.8 du guide) :
    - decaissement bailleur sur compte projet -> split 162 / 462
    - charge de fonctionnement sur projet     -> neutralisation 462 / 702.
    """

    @classmethod
    def setUpTestData(cls):
        from datetime import date
        from apps.finance.models import BankAccount, ChartOfAccount
        from apps.projects.models import Project

        # Comptes SYCEBNL critiques (162, 462, 702) - requis par posting.py
        cls.fonds_invest = ChartOfAccount.objects.create(
            code="162", name="Fonds affectes aux investissements", class_number=1,
        )
        cls.fonds_admin = ChartOfAccount.objects.create(
            code="462", name="Fonds d'administration", class_number=4,
        )
        cls.quote_part = ChartOfAccount.objects.create(
            code="702", name="Quote-part fonds admin transferes", class_number=7,
        )

        cls.bank = BankAccount.objects.create(
            name="Banque test SYCEBNL projet", bank_name="X",
        )
        cls.treasury = ChartOfAccount.objects.create(
            code="5211.SYC", name="Tresorerie projet", class_number=5,
            linked_bank_account=cls.bank,
        )
        # Compte 75x subvention bailleur (declenche le split decaissement)
        cls.subv = ChartOfAccount.objects.create(
            code="75.SYC", name="Subvention bailleur test", class_number=7,
        )
        # Compte de charge de fonctionnement (declenche la neutralisation 462/702)
        cls.charge = ChartOfAccount.objects.create(
            code="66.SYC", name="Charges de personnel projet", class_number=6,
        )

        # Projet 80/20 type Banque Mondiale (App.8 du guide)
        cls.project = Project.objects.create(
            code="WB-INFRA-N", title="Projet infra WB",
            start_date=date(2026, 1, 1), end_date=date(2026, 12, 31),
            investment_split_pct=Decimal("80.00"),
            administration_split_pct=Decimal("20.00"),
        )
        # Projet 0/100 (EVE par defaut, tout fonctionnement)
        cls.project_admin_only = Project.objects.create(
            code="EVE-FONC-N", title="Projet 100% fonctionnement",
            start_date=date(2026, 1, 1), end_date=date(2026, 12, 31),
            investment_split_pct=Decimal("0.00"),
            administration_split_pct=Decimal("100.00"),
        )

    def test_donor_disbursement_splits_into_162_and_462(self):
        """App.8 SYCEBNL : decaissement 150M sur projet 80/20 ->
        162 = 120M (invest), 462 = 30M (admin)."""
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 1, 5),
            reference="WB-DISB-1", label="Decaissement Banque Mondiale",
            debit=Decimal("0"), credit=Decimal("150000000"),
            contra_account=self.subv, project=self.project,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertTrue(entry.is_balanced)

        # 3 lignes : tresorerie debit 150M + 162 credit 120M + 462 credit 30M
        self.assertEqual(entry.lines.count(), 3)
        self.assertEqual(
            entry.lines.get(account=self.treasury).debit, Decimal("150000000")
        )
        self.assertEqual(
            entry.lines.get(account=self.fonds_invest).credit, Decimal("120000000")
        )
        self.assertEqual(
            entry.lines.get(account=self.fonds_admin).credit, Decimal("30000000")
        )
        # Le compte 75x subvention n'apparait PAS (remplace par 162/462)
        self.assertFalse(entry.lines.filter(account=self.subv).exists())

    def test_donor_disbursement_100pct_admin_skips_162_line(self):
        """Projet 0/100 : pas de ligne 162, tout passe en 462."""
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 1, 10),
            reference="EVE-DISB-1", label="Decaissement fonctionnement",
            debit=Decimal("0"), credit=Decimal("5000000"),
            contra_account=self.subv, project=self.project_admin_only,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertTrue(entry.is_balanced)
        self.assertEqual(entry.lines.count(), 2)  # treasury + 462 (pas de 162)
        self.assertFalse(entry.lines.filter(account=self.fonds_invest).exists())
        self.assertEqual(
            entry.lines.get(account=self.fonds_admin).credit, Decimal("5000000")
        )

    def test_operating_charge_on_project_adds_462_702_neutralization(self):
        """App.8 SYCEBNL : charge fonctionnement 28M sur projet ->
        ecriture charge + ecriture neutralisation 462 / 702."""
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 3, 15),
            reference="CHARGE-1", label="Salaires equipe projet",
            debit=Decimal("28000000"), credit=Decimal("0"),
            contra_account=self.charge, project=self.project,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertTrue(entry.is_balanced)

        # 4 lignes : charge debit + treasury credit + 462 debit + 702 credit
        self.assertEqual(entry.lines.count(), 4)
        self.assertEqual(
            entry.lines.get(account=self.charge).debit, Decimal("28000000")
        )
        self.assertEqual(
            entry.lines.get(account=self.treasury).credit, Decimal("28000000")
        )
        self.assertEqual(
            entry.lines.get(account=self.fonds_admin).debit, Decimal("28000000")
        )
        self.assertEqual(
            entry.lines.get(account=self.quote_part).credit, Decimal("28000000")
        )

    def test_no_sycebnl_split_without_project(self):
        """Mouvement sans projet rattache -> ecriture standard 2 lignes,
        meme avec un compte 75x ou 6x."""
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry

        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 1),
            reference="BG-1", label="Decaissement BG",
            debit=Decimal("0"), credit=Decimal("2000000"),
            contra_account=self.subv,
            # project=None
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertEqual(entry.lines.count(), 2)
        self.assertTrue(entry.lines.filter(account=self.subv).exists())
        # Aucune ligne 162/462/702
        self.assertFalse(entry.lines.filter(account=self.fonds_invest).exists())
        self.assertFalse(entry.lines.filter(account=self.fonds_admin).exists())
        self.assertFalse(entry.lines.filter(account=self.quote_part).exists())

    def test_immobilisation_charge_on_project_no_neutralization(self):
        """Acquisition d'immo (classe 2) sur projet : pas de 462/702.
        L'extourne fonds invest se fait en cloture (App.8 page 20)."""
        from datetime import date
        from apps.finance.models import BankMovement, JournalEntry, ChartOfAccount

        immo = ChartOfAccount.objects.create(
            code="2442.SYC", name="Materiel informatique test", class_number=2,
        )
        m = BankMovement.objects.create(
            account=self.bank, date_operation=date(2026, 2, 10),
            reference="ACHAT-PC", label="Achat ordinateurs projet",
            debit=Decimal("5000000"), credit=Decimal("0"),
            contra_account=immo, project=self.project,
        )
        entry = JournalEntry.objects.get(source_bank_movement=m)
        self.assertEqual(entry.lines.count(), 2)  # pas de neutralisation
        self.assertFalse(entry.lines.filter(account=self.fonds_admin).exists())
        self.assertFalse(entry.lines.filter(account=self.quote_part).exists())


class FinancialStatementsSycebnlTests(TestCase):
    """Etats financiers au format officiel SYCEBNL (REF AA/CA/XA/FA).

    Scenario minimal :
      - 2 comptes bancaires (5211.x) avec ouvertures
      - 1 charge salaires (6611)
      - 1 produit subvention exploitation (71)
      - 1 acquisition immobilisation (244)
    Verifie que les lignes officielles sortent au bon endroit.
    """

    @classmethod
    def setUpTestData(cls):
        from datetime import date
        from apps.finance.models import (
            BankAccount, ChartOfAccount, JournalEntry, JournalLine,
        )

        # Comptes SYCEBNL essentiels
        cls.bank = BankAccount.objects.create(name="Banque FE test", bank_name="X")
        cls.treasury = ChartOfAccount.objects.create(
            code="5211.FE", name="Tresorerie test", class_number=5,
            linked_bank_account=cls.bank,
        )
        cls.charge_salaires = ChartOfAccount.objects.create(
            code="6611", name="Salaires", class_number=6,
        )
        cls.subv = ChartOfAccount.objects.create(
            code="71", name="Subvention d'exploitation", class_number=7,
        )
        cls.immo = ChartOfAccount.objects.create(
            code="244", name="Materiel mobilier", class_number=2,
        )
        cls.fournisseur = ChartOfAccount.objects.create(
            code="481", name="Fournisseurs d'investissement", class_number=4,
        )

        # Ecriture 1 : subvention recue 5 000 000 (debit tresorerie / credit 71)
        e1 = JournalEntry.objects.create(entry_date=date(2026, 1, 5), label="Subvention test")
        JournalLine.objects.create(entry=e1, account=cls.treasury,
                                   debit=Decimal("5000000"), credit=Decimal("0"))
        JournalLine.objects.create(entry=e1, account=cls.subv,
                                   debit=Decimal("0"), credit=Decimal("5000000"))

        # Ecriture 2 : salaire paye 800 000 (debit charge / credit tresorerie)
        e2 = JournalEntry.objects.create(entry_date=date(2026, 2, 15), label="Salaire")
        JournalLine.objects.create(entry=e2, account=cls.charge_salaires,
                                   debit=Decimal("800000"), credit=Decimal("0"))
        JournalLine.objects.create(entry=e2, account=cls.treasury,
                                   debit=Decimal("0"), credit=Decimal("800000"))

        # Ecriture 3 : acquisition mobilier 1 500 000 (debit immo / credit fournisseur)
        e3 = JournalEntry.objects.create(entry_date=date(2026, 3, 1), label="Mobilier")
        JournalLine.objects.create(entry=e3, account=cls.immo,
                                   debit=Decimal("1500000"), credit=Decimal("0"))
        JournalLine.objects.create(entry=e3, account=cls.fournisseur,
                                   debit=Decimal("0"), credit=Decimal("1500000"))

    def test_balance_sheet_asset_lines(self):
        from apps.finance.financial_statements_sycebnl import (
            compute_balance_sheet_asset,
        )
        lines = compute_balance_sheet_asset()
        by_ref = {l["ref"]: l for l in lines}

        # AL Materiel mobilier = 1 500 000 (debiteur)
        self.assertEqual(by_ref["AL"]["amount"], Decimal("1500000"))
        # AH Immobilisations corporelles (subtotal) = 1 500 000
        self.assertEqual(by_ref["AH"]["amount"], Decimal("1500000"))
        # BW Banques tresorerie = 5 000 000 - 800 000 = 4 200 000 (5211.FE debiteur)
        self.assertEqual(by_ref["BW"]["amount"], Decimal("4200000"))
        # BX TOTAL TRESORERIE ACTIF = 4 200 000
        self.assertEqual(by_ref["BX"]["amount"], Decimal("4200000"))
        # AZ TOTAL ACTIF IMMOBILISE = 1 500 000
        self.assertEqual(by_ref["AZ"]["amount"], Decimal("1500000"))
        # BZ TOTAL GENERAL = AZ + BF + BX = 1 500 000 + 0 + 4 200 000 = 5 700 000
        self.assertEqual(by_ref["BZ"]["amount"], Decimal("5700000"))

    def test_balance_sheet_liability_lines_and_balance(self):
        from apps.finance.financial_statements_sycebnl import (
            compute_balance_sheet_asset, compute_balance_sheet_liability,
        )
        passif = compute_balance_sheet_liability()
        by_ref = {l["ref"]: l for l in passif}

        # DH Fournisseurs (40, 481, 488) = 1 500 000 (creditear sur 481)
        self.assertEqual(by_ref["DH"]["amount"], Decimal("1500000"))
        # CH Solde exercice = subv 5M - salaires 800K = 4 200 000 excedent
        self.assertEqual(by_ref["CH"]["amount"], Decimal("4200000"))
        # CK TOTAL FONDS PROPRES = CH = 4 200 000 (autres sont zero)
        self.assertEqual(by_ref["CK"]["amount"], Decimal("4200000"))
        # DZ TOTAL PASSIF = CK + DV (DH=1.5M) = 4 200 000 + 1 500 000 = 5 700 000
        self.assertEqual(by_ref["DZ"]["amount"], Decimal("5700000"))

        # Bilan equilibre : Actif BZ == Passif DZ
        actif = compute_balance_sheet_asset()
        by_ref_a = {l["ref"]: l for l in actif}
        self.assertEqual(by_ref_a["BZ"]["amount"], by_ref["DZ"]["amount"])

    def test_income_statement_lines(self):
        from apps.finance.financial_statements_sycebnl import (
            compute_income_statement,
        )
        lines = compute_income_statement()
        by_ref = {l["ref"]: l for l in lines}

        # RF Subventions d'exploitations = 5 000 000
        self.assertEqual(by_ref["RF"]["amount"], Decimal("5000000"))
        # TJ Charges de personnel = 800 000
        self.assertEqual(by_ref["TJ"]["amount"], Decimal("800000"))
        # XA REVENUS ACTIVITES ORDINAIRES = 5 000 000
        self.assertEqual(by_ref["XA"]["amount"], Decimal("5000000"))
        # XB CHARGES ACTIVITES ORDINAIRES = 800 000
        self.assertEqual(by_ref["XB"]["amount"], Decimal("800000"))
        # XC RESULTAT ACTIVITES ORDINAIRES = XA - XB = 4 200 000
        self.assertEqual(by_ref["XC"]["amount"], Decimal("4200000"))
        # XE SOLDE EXERCICE = XC + XD = 4 200 000
        self.assertEqual(by_ref["XE"]["amount"], Decimal("4200000"))

    def test_cash_flow_statement_lines(self):
        from apps.finance.financial_statements_sycebnl import (
            compute_cash_flow_statement,
        )
        tft = compute_cash_flow_statement(opening_treasury=Decimal("0"))
        by_ref = {l["ref"]: l for l in tft["lines"]}

        # FB Encaissement subventions exploitation = 5 000 000 (credit brut 71)
        self.assertEqual(by_ref["FB"]["amount"], Decimal("5000000"))
        # FG Decaissement personnel = 800 000 (debit brut 66)
        self.assertEqual(by_ref["FG"]["amount"], Decimal("800000"))
        # FJ Acquisitions corporelles = 1 500 000 (debit brut 22-24)
        self.assertEqual(by_ref["FJ"]["amount"], Decimal("1500000"))


class ExpensePublicUIPermissionsTests(TestCase):
    """L'UI expense /finance/demandes/ doit exiger un user connecte."""

    def test_anonymous_redirects_to_login(self):
        client = Client()
        response = client.get("/finance/demandes/")
        # @login_required redirect vers /connexion/?next=... (LOGIN_URL applicatif)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/connexion/", response.url)
        self.assertIn("next=/finance/demandes/", response.url)


class ExpenseRequestWorkflowTests(TestCase):
    """Workflow ExpenseRequest : SUBMITTED -> APPROVED si les 3 valideurs OK,
    REJECTED si un seul rejette."""

    @classmethod
    def setUpTestData(cls):
        from datetime import date
        from apps.accounts.models import Role
        from apps.finance.models import BudgetLine, ExpenseRequest, ExpenseValidation
        from apps.hr.models import Employee
        from apps.references.models import BudgetCategory

        cls.raf = Role.objects.create(code="RAF", name="RAF")
        cls.dp = Role.objects.create(code="DP", name="DP")
        cls.se = Role.objects.create(code="SE", name="SE")
        cls.category = BudgetCategory.objects.create(code="EX_CAT", name="Cat test")
        cls.budget_line = BudgetLine.objects.create(
            project=None,
            category=cls.category,
            code="EX-LINE-1",
            description="Ligne test",
            planned_amount=Decimal("0"),
            fiscal_year=2026,
        )
        cls.employee = Employee.objects.create(
            matricule="EX-001",
            first_name="Test",
            last_name="Requester",
            hire_date=date(2024, 1, 1),
            status=Employee.Status.ACTIVE,
        )

    def _make_submitted_request(self):
        from apps.finance.models import ExpenseRequest, ExpenseValidation

        req = ExpenseRequest.objects.create(
            project=None,
            budget_line=self.budget_line,
            requester=self.employee,
            title="Achat papier",
            motif="Reapprovisionnement papier bureau",
            requested_amount=Decimal("25000"),
            status=ExpenseRequest.Status.SUBMITTED,
        )
        # Cree les 3 validations PENDING
        for role in (self.raf, self.dp, self.se):
            ExpenseValidation.objects.create(
                request=req, role=role, decision=ExpenseValidation.Decision.PENDING
            )
        return req

    def test_request_becomes_approved_when_all_three_approve(self):
        from apps.finance.models import ExpenseRequest, ExpenseValidation

        req = self._make_submitted_request()
        for v in req.validations.all():
            v.decision = ExpenseValidation.Decision.APPROVED
            v.save()
        req.refresh_from_db()
        self.assertEqual(req.status, ExpenseRequest.Status.APPROVED)
        self.assertIsNotNone(req.decided_at)

    def test_request_becomes_rejected_on_first_rejection(self):
        from apps.finance.models import ExpenseRequest, ExpenseValidation

        req = self._make_submitted_request()
        first_validation = req.validations.first()
        first_validation.decision = ExpenseValidation.Decision.REJECTED
        first_validation.comment = "Motif insuffisant"
        first_validation.save()
        req.refresh_from_db()
        self.assertEqual(req.status, ExpenseRequest.Status.REJECTED)

    def test_request_stays_submitted_when_partial_approval(self):
        from apps.finance.models import ExpenseRequest, ExpenseValidation

        req = self._make_submitted_request()
        v = req.validations.first()
        v.decision = ExpenseValidation.Decision.APPROVED
        v.save()
        req.refresh_from_db()
        self.assertEqual(req.status, ExpenseRequest.Status.SUBMITTED)

    def test_unique_validation_per_role(self):
        from django.db import IntegrityError, transaction
        from apps.finance.models import ExpenseValidation

        req = self._make_submitted_request()
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                ExpenseValidation.objects.create(
                    request=req, role=self.raf, decision=ExpenseValidation.Decision.PENDING
                )


class BankMovementUniqueConstraintTests(TestCase):
    def test_duplicate_movement_is_rejected(self):
        from datetime import date
        from django.db import IntegrityError, transaction
        from apps.finance.models import BankAccount, BankMovement

        account = BankAccount.objects.create(name="Test BA", bank_name="X")
        BankMovement.objects.create(
            account=account,
            date_operation=date(2026, 1, 15),
            reference="REF-1",
            label="Mouvement test",
            debit=Decimal("100.00"),
            credit=Decimal("0"),
        )
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                BankMovement.objects.create(
                    account=account,
                    date_operation=date(2026, 1, 15),
                    reference="REF-1",
                    label="Mouvement test (doublon)",
                    debit=Decimal("100.00"),
                    credit=Decimal("0"),
                )


@override_settings(
    EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
    DEFAULT_FROM_EMAIL="EVE Pilot <no-reply@eve-sn.org>",
    SITE_BASE_URL="http://testserver",
)
class ExpenseNotificationTests(TestCase):
    """Notifications email du workflow de demande de depense."""

    @classmethod
    def setUpTestData(cls):
        from apps.accounts.models import Role, User, UserRole
        from apps.finance.models import BudgetLine, ExpenseRequest, ExpenseValidation
        from apps.hr.models import Employee

        cls.raf = Role.objects.create(code="RAF", name="RAF")
        cls.dp = Role.objects.create(code="DP", name="DP")
        cls.se = Role.objects.create(code="SE", name="SE")
        cls.category = BudgetCategory.objects.create(code="NOTIF_CAT", name="Cat notif")
        cls.budget_line = BudgetLine.objects.create(
            project=None,
            category=cls.category,
            code="NOTIF-LINE-1",
            description="Ligne notif",
            planned_amount=Decimal("0"),
            fiscal_year=2026,
        )
        cls.requester_employee = Employee.objects.create(
            matricule="NOTIF-001",
            first_name="Demandeur",
            last_name="Notif",
            hire_date=date(2024, 1, 1),
            status=Employee.Status.ACTIVE,
            email_professional="demandeur@eve-sn.org",
        )
        # Valideurs avec comptes User + roles
        cls.user_raf = User.objects.create_user(
            username="raf_user", email="raf@eve-sn.org",
            first_name="Le", last_name="Raf", password="x",
        )
        cls.user_dp = User.objects.create_user(
            username="dp_user", email="dp@eve-sn.org",
            first_name="Le", last_name="Dp", password="x",
        )
        cls.user_se = User.objects.create_user(
            username="se_user", email="se@eve-sn.org",
            first_name="Le", last_name="Se", password="x",
        )
        UserRole.objects.create(user=cls.user_raf, role=cls.raf)
        UserRole.objects.create(user=cls.user_dp, role=cls.dp)
        UserRole.objects.create(user=cls.user_se, role=cls.se)

    def _make_submitted_request(self):
        from apps.finance.models import ExpenseRequest, ExpenseValidation

        req = ExpenseRequest.objects.create(
            project=None,
            budget_line=self.budget_line,
            requester=self.requester_employee,
            title="Achat fournitures",
            motif="Test notification",
            requested_amount=Decimal("30000"),
            status=ExpenseRequest.Status.SUBMITTED,
        )
        for role in (self.raf, self.dp, self.se):
            ExpenseValidation.objects.create(
                request=req, role=role, decision=ExpenseValidation.Decision.PENDING
            )
        return req

    def test_notify_validators_on_submit_emails_all_three(self):
        from apps.finance.notifications import notify_validators_on_submit

        req = self._make_submitted_request()
        mail.outbox = []
        sent = notify_validators_on_submit(req)
        self.assertTrue(sent)
        self.assertEqual(len(mail.outbox), 1)
        msg = mail.outbox[0]
        self.assertCountEqual(
            msg.to, ["raf@eve-sn.org", "dp@eve-sn.org", "se@eve-sn.org"]
        )
        self.assertIn(f"DD-{req.id}", msg.subject)

    def test_notify_requester_on_decision_emails_requester(self):
        from apps.finance.models import ExpenseRequest
        from apps.finance.notifications import notify_requester_on_decision

        req = self._make_submitted_request()
        req.status = ExpenseRequest.Status.APPROVED
        req.save(update_fields=["status", "updated_at"])
        mail.outbox = []
        sent = notify_requester_on_decision(req)
        self.assertTrue(sent)
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, ["demandeur@eve-sn.org"])
        self.assertIn("APPROUVEE", mail.outbox[0].body)

    def test_notify_requester_without_email_returns_false(self):
        from apps.finance.models import ExpenseRequest
        from apps.finance.notifications import notify_requester_on_decision
        from apps.hr.models import Employee

        no_email_emp = Employee.objects.create(
            matricule="NOTIF-002",
            first_name="Sans",
            last_name="Mail",
            hire_date=date(2024, 1, 1),
            status=Employee.Status.ACTIVE,
        )
        req = self._make_submitted_request()
        req.requester = no_email_emp
        req.status = ExpenseRequest.Status.REJECTED
        req.save(update_fields=["requester", "status", "updated_at"])
        mail.outbox = []
        sent = notify_requester_on_decision(req)
        self.assertFalse(sent)
        self.assertEqual(len(mail.outbox), 0)

    def test_submit_action_triggers_validator_notification(self):
        from apps.accounts.models import User
        from apps.finance.models import ExpenseRequest

        # Le demandeur a besoin d'un compte User lie a son Employee.
        requester_user = User.objects.create_user(
            username="demandeur_user", email="demandeur@eve-sn.org",
            first_name="Demandeur", last_name="Notif", password="x",
        )
        requester_user.employee = self.requester_employee
        requester_user.save(update_fields=["employee"])

        req = ExpenseRequest.objects.create(
            project=None,
            budget_line=self.budget_line,
            requester=self.requester_employee,
            title="Achat via UI",
            motif="Test soumission",
            requested_amount=Decimal("12000"),
            status=ExpenseRequest.Status.DRAFT,
        )
        client = Client()
        client.force_login(requester_user)
        mail.outbox = []
        response = client.post(
            f"/finance/demandes/{req.id}/", {"action": "submit"}
        )
        self.assertEqual(response.status_code, 302)
        req.refresh_from_db()
        self.assertEqual(req.status, ExpenseRequest.Status.SUBMITTED)
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn(f"DD-{req.id}", mail.outbox[0].subject)


class SaintLouisBudgetLinkingTests(TestCase):
    """Commande link_budget_lines_to_activities_saint_louis : prefix -> Activity."""

    @classmethod
    def setUpTestData(cls):
        from apps.activities.models import Activity

        cls.project = Project.objects.create(
            code="NOUSCIMS-SL-2026",
            title="SL test",
            start_date=date(2025, 8, 1),
            end_date=date(2028, 7, 31),
        )
        cls.category = BudgetCategory.objects.create(code="SL_TEST", name="cat test")
        # Trois activites cibles, plus une activite hors mapping.
        cls.a_r1_a2 = Activity.objects.create(
            project=cls.project, code="SL-R1-A2", title="Orientation des elus"
        )
        cls.a_r3_a1 = Activity.objects.create(
            project=cls.project, code="SL-R3-A1", title="Conventions tripartites"
        )
        cls.a_r3_a8 = Activity.objects.create(
            project=cls.project, code="SL-R3-A8", title="Prise en charge malnutris"
        )
        # 4 lignes : 3 doivent matcher, 1 reste transverse.
        cls.bl_t1 = BudgetLine.objects.create(
            project=cls.project, category=cls.category,
            code="SL-A111-T1-S1-2026", description="Theme 1 / sub 1",
            planned_amount=Decimal("100000"), fiscal_year=2026,
        )
        cls.bl_pec_mam = BudgetLine.objects.create(
            project=cls.project, category=cls.category,
            code="SL-A114-02-2026", description="PEC MAM",
            planned_amount=Decimal("1400000"), fiscal_year=2026,
        )
        cls.bl_conv = BudgetLine.objects.create(
            project=cls.project, category=cls.category,
            code="SL-A114-01-2026", description="Conventions tripartites",
            planned_amount=Decimal("3000000"), fiscal_year=2026,
        )
        cls.bl_admin = BudgetLine.objects.create(
            project=cls.project, category=cls.category,
            code="SL-A4-01-2026", description="Location bureau",
            planned_amount=Decimal("3000000"), fiscal_year=2026,
        )

    def test_linking_assigns_correct_activities(self):
        from django.core.management import call_command

        call_command("link_budget_lines_to_activities_saint_louis")
        self.bl_t1.refresh_from_db()
        self.bl_pec_mam.refresh_from_db()
        self.bl_conv.refresh_from_db()
        self.bl_admin.refresh_from_db()
        self.assertEqual(self.bl_t1.activity_id, self.a_r1_a2.id)
        self.assertEqual(self.bl_pec_mam.activity_id, self.a_r3_a8.id)
        self.assertEqual(self.bl_conv.activity_id, self.a_r3_a1.id)
        # Ligne transverse : non rattachee.
        self.assertIsNone(self.bl_admin.activity_id)

    def test_linking_is_idempotent(self):
        from django.core.management import call_command

        call_command("link_budget_lines_to_activities_saint_louis")
        call_command("link_budget_lines_to_activities_saint_louis")
        self.bl_t1.refresh_from_db()
        self.assertEqual(self.bl_t1.activity_id, self.a_r1_a2.id)


class SaintLouisBudgetAmountsImportTests(TestCase):
    """Helper _row_total et garde-fou fichier absent de l'import xls."""

    def _mock_sheet(self, rows):
        class _Sheet:
            def __init__(self, data):
                self._data = data

            def cell_value(self, row, col):
                return self._data[row][col]
        return _Sheet(rows)

    def test_row_total_uses_total_column_when_filled(self):
        from apps.finance.management.commands.import_budget_amounts_saint_louis import (
            _row_total,
        )

        row = ["", "lib", 25000.0, 6.0, 75000.0, "", 50000.0, "", "", "", 125000.0]
        sheet = self._mock_sheet([row])
        self.assertEqual(_row_total(sheet, 0), Decimal("125000.0"))

    def test_row_total_falls_back_to_annual_sum_when_total_empty(self):
        from apps.finance.management.commands.import_budget_amounts_saint_louis import (
            _row_total,
        )

        # Cas A.1.5/1 : col TOTAL vide, seule ANNEE 1 renseignee.
        row = ["", "lib", 100000.0, 1.0, 100000.0, "", "", "", "", "", ""]
        sheet = self._mock_sheet([row])
        self.assertEqual(_row_total(sheet, 0), Decimal("100000.0"))

    def test_row_total_returns_none_when_all_empty(self):
        from apps.finance.management.commands.import_budget_amounts_saint_louis import (
            _row_total,
        )

        row = ["", "header sans montant", "", "", "", "", "", "", "", "", ""]
        sheet = self._mock_sheet([row])
        self.assertIsNone(_row_total(sheet, 0))

    def test_command_fails_clean_when_xls_missing(self):
        from django.core.management import call_command
        from django.core.management.base import CommandError

        Project.objects.create(
            code="NOUSCIMS-SL-2026", title="SL",
            start_date=date(2025, 8, 1), end_date=date(2028, 7, 31),
        )
        with self.assertRaises(CommandError):
            call_command(
                "import_budget_amounts_saint_louis",
                file="/tmp/this-file-does-not-exist-xyz.xls",
            )
